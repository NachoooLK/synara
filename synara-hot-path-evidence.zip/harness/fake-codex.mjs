#!/usr/bin/env node
import readline from 'node:readline';
if(process.argv.includes('--version')) {console.log('codex 0.140.0');process.exit(0);}
const send=(value)=>process.stdout.write(JSON.stringify(value)+'\n');
const notify=(method,params)=>send({method,params});
let threadId='';
readline.createInterface({input:process.stdin}).on('line',line=>{
  const request=JSON.parse(line);if(request.id===undefined)return;
  const {id,method}=request;
  if(method==='thread/start'||method==='thread/resume') {threadId=request.params.threadId??'fake-'+process.pid;send({id,result:{thread:{id:threadId},model:'gpt-5.4',modelProvider:'openai'}});return;}
  if(method==='account/read'){send({id,result:{account:null}});return;}
  if(method==='turn/start'){
    const turnId='turn-'+Date.now();send({id,result:{turn:{id:turnId,status:'inProgress',items:[]}}});
    notify('turn/started',{threadId,turn:{id:turnId,status:'inProgress'}});
    const item={id:'assistant-'+turnId,type:'agentMessage',text:''};
    notify('item/started',{threadId,turnId,item});
    let n=0;
    const timer=setInterval(()=>{
      const frames=[];
      for(let j=0;j<5;j++) frames.push(JSON.stringify({method:'item/agentMessage/delta',params:{threadId,turnId,itemId:item.id,delta:'Measured streaming text. '}}));
      process.stdout.write(frames.join('\n')+'\n');
      if(n%25===0){const tool={id:'tool-'+turnId+'-'+n,type:'commandExecution',command:'printf fixture',status:'completed',aggregatedOutput:'Fixture tool output.'};notify('item/started',{threadId,turnId,item:tool});notify('item/completed',{threadId,turnId,item:tool});}
      if(++n===100){clearInterval(timer);notify('item/completed',{threadId,turnId,item:{...item,text:'Measured response.'}});notify('turn/completed',{threadId,turn:{id:turnId,status:'completed',items:[]}});}
    },100);
    return;
  }
  if(method==='model/list'){send({id,result:{data:[],nextCursor:null}});return;}
  send({id,result:{}});
});
