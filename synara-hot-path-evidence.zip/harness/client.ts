import { connectOwnerUrl } from './computer-use-fixtures/packaged-client.ts';
import { ClientOrchestrationCommand } from '@synara/contracts';
import { Schema } from 'effect';
import { randomUUID } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
for(let i=0;i<60;i++){try{await fetch('http://127.0.0.1:46171/health');break;}catch{await new Promise(r=>setTimeout(r,500));}}
const client=await connectOwnerUrl('ws://127.0.0.1:46171?token=perf-isolated-token');
const id=()=>randomUUID();
const now=()=>new Date().toISOString();
const model={provider:'codex',model:'gpt-5.4'};
const latency:number[]=[];
const http:number[]=[];
const dispatch=async(command:unknown)=>{const start=performance.now();const result=await client.run(client.api['orchestration.dispatchCommand'](Schema.decodeUnknownSync(ClientOrchestrationCommand)(command)));latency.push(performance.now()-start);return result;};
const projectId=id();
try {
  await dispatch({type:'project.create',commandId:id(),projectId,title:'Performance fixture',workspaceRoot:'/tmp/synara-perf-hot-path/project',createdAt:now()});
  const threads:string[]=[];
  for(let i=0;i<8;i++){
    const threadId=id();threads.push(threadId);
    await dispatch({type:'thread.create',commandId:id(),threadId,projectId,title:'Performance '+i,modelSelection:model,runtimeMode:'full-access',branch:null,worktreePath:null,createdAt:now()});
    await dispatch({type:'thread.turn.start',commandId:id(),threadId,message:{messageId:id(),role:'user',text:'Stream the fixture response.',attachments:[]},modelSelection:model,providerOptions:{codex:{binaryPath:'/tmp/synara-perf-hot-path/fake-codex.mjs',homePath:'/tmp/synara-perf-hot-path/codex',environment:{SYNARA_HOME:'/tmp/synara-perf-hot-path-home'}}},runtimeMode:'full-access',interactionMode:'default',createdAt:now()});
  }
  const until=performance.now()+25000;
  while(performance.now()<until){
    const start=performance.now();await fetch('http://127.0.0.1:46171/health',{signal:AbortSignal.timeout(10000)});http.push(performance.now()-start);
    await dispatch({type:'thread.meta.update',commandId:id(),threadId:threads[0],title:'Measured '+id()});
    await new Promise(resolve=>setTimeout(resolve,100));
  }
  const summarize=(values:number[])=>{values.sort((a,b)=>a-b);return {count:values.length,p50Ms:values[Math.floor(values.length*.5)],p99Ms:values[Math.floor(values.length*.99)],maxMs:values.at(-1)};};
  const details=await client.run(client.api['orchestration.getSnapshot']({}));
  await writeFile(process.env.PERF_CLIENT_OUTPUT!,JSON.stringify({commands:summarize(latency),http:summarize(http),threads:details.threads.map((t)=>({id:t.id,latestTurn:t.latestTurn,session:t.session,messages:t.messages.length}))},null,2));
} finally {await client.close();}
