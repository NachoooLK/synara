if (process.argv[1]?.endsWith('/index.mjs')) {
const fs = require('node:fs');
const { syncBuiltinESMExports } = require('node:module');
const { monitorEventLoopDelay, performance } = require('node:perf_hooks');
const { DatabaseSync, StatementSync } = require('node:sqlite');
const originalWrite = fs.writeFileSync;
let samples = new Map();
let queries = new Map();
const histogram = monitorEventLoopDelay({ resolution: 10 });
histogram.enable();
for (const name of ['openSync','closeSync','readFileSync','lstatSync','statSync','realpathSync','fstatSync','chmodSync','fchmodSync','mkdirSync','readdirSync']) {
  const original = fs[name];
  const wrapper = function(...args) {
    const stack = process.env.PERF_TRACE === '1' ? new Error().stack.split('\n').slice(2,8).join('\n') : '';
    const start = performance.now();
    try { return original.apply(this,args); }
    finally {
      const duration = performance.now()-start;
      const key = name+'\n'+stack;
      const entry = samples.get(key) ?? {name,stack,count:0,totalMs:0,maxMs:0};
      entry.count++; entry.totalMs+=duration; entry.maxMs=Math.max(entry.maxMs,duration);
      samples.set(key,entry);
    }
  };
  Object.assign(wrapper,original);
  fs[name]=wrapper;
}
syncBuiltinESMExports();
const sqls = new WeakMap();
const prepare = DatabaseSync.prototype.prepare;
DatabaseSync.prototype.prepare = function(sql) {const statement=prepare.call(this,sql);sqls.set(statement,sql);return statement;};
for (const name of ['all','run']) {
  const original=StatementSync.prototype[name];
  StatementSync.prototype[name]=function(...args) {
    const sql=sqls.get(this) ?? '<unknown>'; const start=performance.now();
    try{return original.apply(this,args);}finally{
      const duration=performance.now()-start;const entry=queries.get(sql)??{sql,count:0,totalMs:0,maxMs:0};
      entry.count++;entry.totalMs+=duration;entry.maxMs=Math.max(entry.maxMs,duration);queries.set(sql,entry);
    }
  };
}
let window=0;
function flush(label) {
  originalWrite(process.env.PERF_OUTPUT,JSON.stringify({label,window:++window,loop:{p99Ms:histogram.percentile(99)/1e6,maxMs:histogram.max/1e6},fs:[...samples.values()].sort((a,b)=>b.totalMs-a.totalMs),sql:[...queries.values()].sort((a,b)=>b.totalMs-a.totalMs)},null,2));
}
process.on('SIGUSR2',()=>{flush('window');samples=new Map();queries=new Map();histogram.reset();});
process.on('exit',()=>{process.env.PERF_OUTPUT += '.exit.json';flush('exit');});

}
