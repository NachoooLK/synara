# Profiling artifact bootstrap

Run from an isolated checkout of Synara at a83a6248b (before) or the PR branch (after).
Use Node24 and Bun1.4.2. These are synthetic fixtures only; never use Stable/Beta homes.

1. Copy harness/* into /tmp/synara-perf-hot-path; make fake-codex.mjs executable.
2. Create /tmp/synara-perf-hot-path/{evidence,codex,project}. Put cli_auth_credentials_store = "file" in codex/config.toml.
3. Initialize project as a Git repository and make one fixture commit (local fixture identity only).
4. Copy fixture-settings.json to /tmp/synara-perf-hot-path-home2/dev/settings.json.
5. Copy harness/client.ts to scripts/.perf-hot-path.ts in the checkout. It reuses the existing packaged-client owner connection.
6. Build via bun run --cwd apps/server build. Save the base dist to /tmp/synara-perf-hot-path/baseline-dist and link that directory's node_modules to the checkout's apps/server/node_modules.
7. Check both IPv4 and IPv6 listeners for ports 46171/46172 and use the dev runner's isolation dry-run before captures. Remove inherited auth only from fixture processes (run.py does this).
8. Run python3 /tmp/synara-perf-hot-path/run.py LABEL [40]. PERF_DIST selects the base bundle for a before capture. Each label needs a fresh fixture home.
9. For the offline SQLite benchmark, copy fixture-state.sqlite to /tmp/synara-perf-hot-path/home-before-idle-tools/dev/state.sqlite, run seed-large.py, then sqlite-bench.mjs. The JSON result records the removed trial-index measurements; recreate the trial index from REPORT.md's causal message ordering if repeating that experiment.
10. Delete the temporary scripts/.perf-hot-path.ts before workspace checks/committing. Do not commit raw profiles or database fixtures into main.

The supervisor starts only a fake JSONL provider, measures a 25s polling window plus setup, flushes counters with SIGUSR2, and stops its own workers/server. PERF_TRACE stack collection is diagnostic only and unsuitable for latency comparisons.

Raw profile paths include the isolated checkout path. JSON contains synthetic thread IDs and SQL text, not provider secrets or production data. The archive includes only the accepted before/final captures; discarded/intermediate probes are excluded.
