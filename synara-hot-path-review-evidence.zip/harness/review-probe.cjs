if (process.argv[1]?.endsWith('/index.mjs')) {
const fs = require('node:fs');
const { syncBuiltinESMExports } = require('node:module');
const { monitorEventLoopDelay, performance } = require('node:perf_hooks');
const { DatabaseSync, StatementSync } = require('node:sqlite');
const originalWrite = fs.writeFileSync;
let samples = new Map();
let queries = new Map();
const histogram = monitorEventLoopDelay({ resolution: 10 });
histogram.enable();
for (const name of ['openSync','closeSync','readFileSync','lstatSync','statSync','realpathSync','fstatSync','chmodSync','fchmodSync','mkdirSync','readdirSync']) {
  const original = fs[name];
  const wrapper = function(...args) {
    const stack = process.env.PERF_TRACE === '1' ? new Error().stack.split('\n').slice(2,8).join('\n') : '';
    const start = performance.now();
    try { return original.apply(this,args); }
    finally {
      const duration = performance.now()-start;
      const key = name+'\n'+stack;
      const entry = samples.get(key) ?? {name,stack,count:0,totalMs:0,maxMs:0};
      entry.count++; entry.totalMs+=duration; entry.maxMs=Math.max(entry.maxMs,duration);
      samples.set(key,entry);
    }
  };
  Object.assign(wrapper,original);
  fs[name]=wrapper;
}
syncBuiltinESMExports();
const sqls = new WeakMap();
const prepare = DatabaseSync.prototype.prepare;
DatabaseSync.prototype.prepare = function(sql) {const statement=prepare.call(this,sql);sqls.set(statement,sql);return statement;};
for (const name of ['all','run']) {
  const original=StatementSync.prototype[name];
  StatementSync.prototype[name]=function(...args) {
    const sql=sqls.get(this) ?? '<unknown>'; const start=performance.now();
    try{return original.apply(this,args);}finally{
      const duration=performance.now()-start;const entry=queries.get(sql)??{sql,count:0,totalMs:0,maxMs:0};
      entry.count++;entry.totalMs+=duration;entry.maxMs=Math.max(entry.maxMs,duration);queries.set(sql,entry);
    }
  };
}
let metrics;
const ingressReferences = [];
const admitted = new WeakMap();
function resetIngress() { metrics={offered:{},published:{},results:{},checks:0,checksActive:0,checksPeak:0,delay:[],emissionDelay:[],checkDelay:[],queueHighWater:0,bytesHighWater:0}; }
resetIngress();
function increment(target,key) { target[key]=(target[key]??0)+1; }
function summarize(values) { const sorted=values.slice().sort((a,b)=>a-b);return {count:sorted.length,p50Ms:sorted[Math.floor(sorted.length*.5)]??0,p99Ms:sorted[Math.floor(sorted.length*.99)]??0,maxMs:sorted.at(-1)??0}; }
globalThis.__synaraPerf = {
 observe(ingress,manager) {
  ingressReferences.push(ingress);
  const offer=ingress.offer;
  ingress.offer=(item)=>{
   admitted.set(item,{at:performance.now(),emitted:item.nativeEvent.payload?._perfSentAt});
   increment(metrics.offered,item.nativeEvent.method);
   const result=offer(item);increment(metrics.results,result);
   const status=ingress.status();metrics.queueHighWater=Math.max(metrics.queueHighWater,status.queued);metrics.bytesHighWater=Math.max(metrics.bytesHighWater,status.queuedBytes);
   return result;
  };
  if(typeof manager.inspectSessionAsync !== 'function')return;
  const inspect=manager.inspectSessionAsync.bind(manager);
  manager.inspectSessionAsync=async(...args)=>{
   const start=performance.now();metrics.checks++;metrics.checksActive++;metrics.checksPeak=Math.max(metrics.checksPeak,metrics.checksActive);
   try{return await inspect(...args);}finally{metrics.checksActive--;metrics.checkDelay.push(performance.now()-start);}
  };
 },
 publish(item) {
  const info=admitted.get(item);increment(metrics.published,item.nativeEvent.method);
  if(info) {metrics.delay.push(performance.now()-info.at);if(typeof info.emitted==='number')metrics.emissionDelay.push(Date.now()-info.emitted);admitted.delete(item);}
 }
};
function ingressSummary() { return {...metrics,delay:summarize(metrics.delay),emissionDelay:summarize(metrics.emissionDelay),checkDelay:summarize(metrics.checkDelay),status:ingressReferences.map(ingress=>ingress.status())}; }
let window=0;
function flush(label) {
  originalWrite(process.env.PERF_OUTPUT,JSON.stringify({label,window:++window,loop:{p99Ms:histogram.percentile(99)/1e6,maxMs:histogram.max/1e6},fs:[...samples.values()].sort((a,b)=>b.totalMs-a.totalMs),ingress:ingressSummary(),sql:[...queries.values()].sort((a,b)=>b.totalMs-a.totalMs)},null,2));
}
process.on('SIGUSR2',()=>{flush('window');samples=new Map();queries=new Map();histogram.reset();resetIngress();});
process.on('exit',()=>{process.env.PERF_OUTPUT += '.exit.json';flush('exit');});

}
