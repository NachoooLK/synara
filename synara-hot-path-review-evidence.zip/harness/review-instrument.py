import pathlib, shutil, sys
source=pathlib.Path(sys.argv[1]); destination=pathlib.Path(sys.argv[2])
shutil.copytree(source,destination,dirs_exist_ok=True,symlinks=True)
file=destination/'index.mjs';text=file.read_text()
start=text.index('//#region src/provider/Layers/CodexAdapter.ts');end=text.index('//#endregion',start)
section=text[start:end]
conditional='if (item.trustedClose || !item.isAuthRejected()) yield* Queue.offerAll(runtimeEventQueue, runtimeEvents);'
if conditional in section:
 section=section.replace(conditional,'if (item.trustedClose || !item.isAuthRejected()) { globalThis.__synaraPerf.publish(item); yield* Queue.offerAll(runtimeEventQueue, runtimeEvents); }')
else:
 publish='yield* Queue.offerAll(runtimeEventQueue, runtimeEvents);';assert section.count(publish)==1
 section=section.replace(publish,'globalThis.__synaraPerf.publish(item); '+publish)
listener='const listener = (event) => {';assert section.count(listener)==1
section=section.replace(listener,'globalThis.__synaraPerf.observe(ingress, manager);\n'+listener)
file.write_text(text[:start]+section+text[end:])
modules=destination/'node_modules'
if not modules.exists():modules.symlink_to(source.parent/'node_modules',target_is_directory=True)
