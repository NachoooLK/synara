import os, pathlib, subprocess, time, signal, json, urllib.request, sys
root=pathlib.Path('/tmp/synara-perf-hot-path')
label=sys.argv[1]
load=int(sys.argv[2]) if len(sys.argv)>2 else 0
home=root/('home-'+label)
(home/'dev').mkdir(parents=True,exist_ok=True)
settings=json.loads((root/'review-settings.json').read_text());settings['settings']['providers']['codex'].update(binaryPath=str(root/'review-fake-codex.mjs'),homePath=str(root/'review-codex'));(home/'dev/settings.json').write_text(json.dumps(settings))
env=os.environ.copy();env.pop('SYNARA_AUTH_TOKEN',None)
env.update(SYNARA_HOME=str(home/'dev'),CODEX_HOME=str(root/'review-codex'),PERF_OUTPUT=str(root/'evidence'/f'{label}.json'))
(root/'evidence'/f'{label}-host.json').write_text(json.dumps({'start':subprocess.check_output(['uptime'],text=True),'workers':load}));
log=open(root/f'{label}-server.log','w')
server=subprocess.Popen(['node','--require',str(root/'review-probe.cjs'),'--cpu-prof','--cpu-prof-dir='+str(root/'evidence'),'--cpu-prof-name='+label+'.cpuprofile',os.environ.get('PERF_DIST','apps/server/dist/index.mjs'),'--home-dir',str(home),'--host','127.0.0.1','--port','46171','--dev-url','http://localhost:46172','--no-browser','--auth-token','perf-isolated-token'],env=env,stdout=log,stderr=log)
burn=None
try:
  for attempt in range(100):
    if server.poll() is not None:raise RuntimeError('server exited')
    try:
      urllib.request.urlopen('http://127.0.0.1:46171/health',timeout=1);break
    except Exception:time.sleep(.5)
  else:raise RuntimeError('server did not start')
  if load:
    burn=subprocess.Popen(['node','-e',f"const {{Worker}}=require('node:worker_threads');for(let i=0;i<{load};i++)new Worker('let x=0;for(;;)x=Math.sin(x+1)',{{eval:true}});setTimeout(()=>process.exit(),60000)"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    time.sleep(2)
  server.send_signal(signal.SIGUSR2);time.sleep(.1)
  (root/'evidence'/f'{label}-host.json').write_text(json.dumps({'windowStart':subprocess.check_output(['uptime'],text=True),'workers':load}))
  env['PERF_CLIENT_OUTPUT']=str(root/'evidence'/f'{label}-client.json')
  with open(root/f'{label}-client.log','w') as clientlog:
    client=subprocess.run(['bun','scripts/.perf-hot-path.ts'],env=env,stdout=clientlog,stderr=clientlog,timeout=90)
  server.send_signal(signal.SIGUSR2)
  for attempt in range(120):
    try:
      if json.loads((root/'evidence'/f'{label}.json').read_text())['window'] >= 2:break
    except Exception:pass
    time.sleep(.5)
  else:raise RuntimeError('measurement did not flush')
  host=json.loads((root/'evidence'/f'{label}-host.json').read_text());host['windowEnd']=subprocess.check_output(['uptime'],text=True);(root/'evidence'/f'{label}-host.json').write_text(json.dumps(host));
  print('client exit',client.returncode,flush=True)
  d=json.loads((root/'evidence'/f'{label}.json').read_text());print(d['loop'],flush=True)
  if client.returncode:print((root/f'{label}-client.log').read_text()[:1500],flush=True)
finally:
  if burn:burn.terminate();burn.wait(timeout=10)
  server.send_signal(signal.SIGINT)
  try:server.wait(timeout=50)
  except subprocess.TimeoutExpired:server.kill();server.wait()
  log.close()
