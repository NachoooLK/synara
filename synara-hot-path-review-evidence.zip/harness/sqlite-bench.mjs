import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {performance} from 'node:perf_hooks';
const root='/tmp/synara-perf-hot-path';
const db=new DatabaseSync(root+'/large-state.sqlite');
db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA temp_store=MEMORY;');
const threads=db.prepare('SELECT thread_id FROM projection_threads').all().map(x=>x.thread_id);
const insert=db.prepare('INSERT OR IGNORE INTO projection_thread_messages(thread_id,message_id,role,text,is_streaming,created_at,updated_at,sequence) VALUES(?,?,?,?,?,?,?,?)');
db.exec('BEGIN');
for(let i=0;i<10000;i++)insert.run(threads[i%threads.length],'large-message-'+i,'assistant','Synthetic message text. '.repeat(20),0,'2026-10-01T00:00:00Z','2026-10-01T00:00:00Z',i+5000);
db.exec('COMMIT');db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
const queries=JSON.parse(fs.readFileSync(root+'/evidence/before-idle-tools.json')).sql;
const pick=(filter)=>queries.find(x=>filter(x.sql)).sql;
const eventSql=pick(sql=>sql.includes('SELECT COALESCE(MAX(sequence)')&&sql.includes('stream_id = ?')); 
console.log(eventSql);
const snapshots=[
 ['thread message preview',pick(s=>s.includes('message_rank')&&s.includes('WHERE thread_id = ?')),[threads[0],threads[0],200,200]],
 ['global message snapshot',pick(s=>s.includes('message_rank')&&s.includes('thread_id IN (SELECT')),[200]],
 ['provider event bounded replay',pick(s=>s.includes('SELECT sequence, event_json')&&s.includes('FROM provider_runtime_events')&&s.includes('LIMIT ?')),[0,1000000,100]],
 ['thread metadata high water',eventSql,['bulk-thread-200']],
];
const results=[];
for(const [label,sql,params] of snapshots){
 const statement=db.prepare(sql);const times=[];let rows;
 for(let i=0;i<21;i++){const t=performance.now();rows=statement.all(...params).length;times.push(performance.now()-t);}
 const firstMs=times.shift();times.sort((a,b)=>a-b);
 results.push({label,rows,firstMs,p50Ms:times[10],p99Ms:times.at(-1),sql,plan:db.prepare('EXPLAIN QUERY PLAN '+sql).all(...params)});
}
fs.writeFileSync(root+'/evidence/sqlite-large.json',JSON.stringify({bytes:fs.statSync(root+'/large-state.sqlite').size,events:db.prepare('SELECT count(*) AS n FROM orchestration_events').get().n,messages:db.prepare('SELECT count(*) AS n FROM projection_thread_messages').get().n,results},null,2));
console.log(results.map(({label,rows,firstMs,p50Ms,p99Ms})=>({label,rows,firstMs,p50Ms,p99Ms})));db.close();
