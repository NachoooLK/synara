import sqlite3,pathlib,time,json
root=pathlib.Path('/tmp/synara-perf-hot-path'); target=root/'large-state.sqlite'
c=sqlite3.connect(target); src=sqlite3.connect(root/'home-before-idle-tools/dev/state.sqlite');src.backup(c);src.close()
c.execute('PRAGMA journal_mode=OFF');c.execute('PRAGMA synchronous=OFF')
t=time.monotonic();payload=json.dumps({'text':'Synthetic archived event. '*100})
q="INSERT INTO orchestration_events(event_id,aggregate_kind,stream_id,stream_version,event_type,occurred_at,actor_kind,payload_json,metadata_json) VALUES(?,?,?,?,?,?,?,?,?)"
for start in range(0,300000,5000):
 c.executemany(q,((f'bulk-event-{i}','thread',f'bulk-thread-{i//1000}',i%1000+1,'thread.message.assistant.delta','2026-10-01T00:00:00.000Z','provider',payload,'{}') for i in range(start,start+5000)));c.commit()
print(json.dumps({'bytes':target.stat().st_size,'events':c.execute('select count(*) from orchestration_events').fetchone()[0],'seedSeconds':time.monotonic()-t}),flush=True)
c.close()
