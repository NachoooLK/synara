# Review profiling evidence

Synthetic fixtures only. Never use a Stable/Beta home or production database.
Use Node 24.21/Bun 1.4.2; keep global checks out of the CPU capture window.

1. Extract harness files to /tmp/synara-perf-hot-path. Create evidence/, project/ and review-codex/. Copy fixture/auth.json and fixture/config.toml to review-codex/, chmod both 600 and the fake provider executable 755. Copy fixture/settings.json to review-settings.json.
2. Initialize project/ as a local Git repository with a fixture commit and local fixture identity.
3. Build server bundles separately at upstream a83a6248b, PR pre-review 3e48382 and the final PR commit, using bun run --cwd apps/server build. Keep their uninstrumented dist directories outside source changes. Reuse installed workspace dependencies; link each copied bundle directory's node_modules to its source checkout's apps/server/node_modules.
4. Run python3 review-instrument.py SOURCE_DIST DESTINATION_DIST for each. The script inserts only temporary observation hooks in the copied Codex adapter bundle, not source. Legacy upstream does not have inspectSessionAsync; the probe skips that counter there.
5. Copy review-client.ts to scripts/.perf-hot-path.ts in the working checkout. It imports the existing packaged-client owner WebSocket fixture. Check both IPv4/IPv6 listeners for 46171/46172 and the dev runner isolation dry-run.
6. From the checkout root, run PERF_DIST=DESTINATION_DIST/index.mjs python3 /tmp/synara-perf-hot-path/review-run.py FRESH_LABEL [40]. Each label gets its own Synara/overlay home. The synthetic Codex source is shared but auth/config remain fixed. Do not overlap captures. The supervisor clears inherited SYNARA_AUTH_TOKEN only in fixture processes and stops its own finite workers/server.
7. Remove scripts/.perf-hot-path.ts before any workspace check or commit.

Accepted captures: review-upstream-{idle,load}-valid; review-before-idle-1-valid; review-{before,after}-idle-2; review-after-idle-1; review-{before,after}-load-{1,2}. All have client exit 0. Discarded setup captures are excluded.

The latency window begins after server initialization, includes session creation, a 25-second health/metadata-command loop, final snapshot and connection close. CPU profiles also include startup/shutdown. Admission-to-publication delay starts after admission; upstream's synchronous auth occurs before that point. Child _perfSentAt timestamps expose emission-to-publication delay separately. Ingress counts/status/high-water/check starts are actual runtime observations. Final check count means inspector entry, not proof that a native lease remains held after timeout; gated real-fs tests prove the latter.

Original SQLite measurements are retained as evidence/sqlite-large.json and the original evidence archive has the fixture DB/bootstrap. No production DB was accessed, no worker move implemented, no migration added.

The measured security/coalescing paths are final. Subsequent source cleanup was a type-only optional annotation and removal of an unnecessary Set spread during abort; neither changes the measured streaming path. Full workspace tests/typecheck validate the final source.

No server logs, production homes, actual credentials or 1.30 GB database are published. Fixture auth is explicitly synthetic. Profiles contain local source URLs and synthetic IDs.
